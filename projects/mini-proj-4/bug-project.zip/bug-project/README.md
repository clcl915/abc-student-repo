# Hehe Doraemon
A browser extension that populates any page with a hehe Doraemon sticker.

Install this on your friends browsers to prank them. Clicking on the clown icon will infest their page with a bit of fun.
